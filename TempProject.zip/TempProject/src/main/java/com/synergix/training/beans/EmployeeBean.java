package com.synergix.training.beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.synergix.training.utils.DBUtils;

@Named
@SessionScoped
public class EmployeeBean implements Serializable {

	@Inject
	DBUtils dbUtils;

	public List<Employee> getEmployeeList() {
		Employee e1 = new Employee();
		e1.setId(1);
		e1.setName("John");
		e1.setDateOfBirth(new Date());
		e1.setJoinDate(new Date());
		e1.setYearsOfExperience(3);
		Employee e2 = new Employee();
		e2.setId(2);
		e2.setName("Jack");
		e2.setDateOfBirth(new Date());
		e2.setJoinDate(new Date());
		e2.setYearsOfExperience(4);

		List<Employee> list = new ArrayList<>();
		list.add(e1);
		list.add(e2);

		return list;

	}

	public List<Employee> getEmployeeListFromDB() {
		Connection con = dbUtils.getConnection();

		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select * from employee");
			ResultSet result = ps.executeQuery();

			List<Employee> list = new ArrayList<Employee>();

			while (result.next()) {
				Employee e = new Employee();
				e.setId(result.getInt("id"));
				e.setName(result.getString("name"));
		        e.setDateOfBirth(dbUtils.sqlDateToUtilDate(result.getDate("date_of_birth")));
		        e.setJoinDate(dbUtils.sqlDateToUtilDate(result.getDate("join_date")));
		        e.setYearsOfExperience(result.getInt("years_of_experience"));
				list.add(e);
			}

			return list;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}

	}
	
	public Employee getEmployeeById(int id){
		Connection con = dbUtils.getConnection();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select * from employee where id = ?");
			ps.setInt(1, id);
			ResultSet result = ps.executeQuery();
			Employee e = new Employee();
			while (result.next()) {
				e.setId(result.getInt("id"));
				e.setName(result.getString("name"));
		        e.setDateOfBirth(dbUtils.sqlDateToUtilDate(result.getDate("date_of_birth")));
		        e.setJoinDate(dbUtils.sqlDateToUtilDate(result.getDate("join_date")));
		        e.setYearsOfExperience(result.getInt("years_of_experience"));
			}
			return e;
		}catch (SQLException e1) {
			e1.printStackTrace();
			return null;
		}
	}
}
