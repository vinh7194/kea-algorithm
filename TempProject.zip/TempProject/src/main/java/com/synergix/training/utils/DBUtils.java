package com.synergix.training.utils;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
public class DBUtils implements Serializable {
	public Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		Connection connection = null;
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/training?autoReconnect=true&useSSL=false","root", "123456xyz");
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

		if (connection != null) {
			System.out.println("You made it, take control your database now!");
			return connection;
		} else {
			System.out.println("Failed to make connection!");
			return null;
		}
	}
	
	public java.util.Date sqlDateToUtilDate(java.sql.Date date){
	    if(date != null) {
	        java.util.Date utilDate = new java.util.Date(date.getTime());
	        return utilDate;
	    }
	    return null;
	}
}
