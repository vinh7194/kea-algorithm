package com.synergix.training.beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.synergix.training.utils.DBUtils;

@Named
@SessionScoped
public class DepartmentBean implements Serializable{
	@Inject
	DBUtils dbUtils;
	@Inject
	EmployeeBean employeeBean;
	
	public List<Department> getDepartmentList() {
		Connection con = dbUtils.getConnection();

		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select * from department");
			ResultSet result = ps.executeQuery();

			List<Department> list = new ArrayList<>();

			while (result.next()) {
				Department department = new Department();
				department.setId(result.getInt("id"));
				department.setName(result.getString("name"));
				department.setCreatedDate(dbUtils.sqlDateToUtilDate(result.getDate("created_date")));
				Employee leader = employeeBean.getEmployeeById(result.getInt("leader_code"));
				department.setLeader(leader);
				list.add(department);
			}

			return list;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}

	}
}
