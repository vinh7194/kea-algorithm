package com.synergix.jpademo.beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;

import com.synergix.jpademo.helper.EntityManagerUtil;

@Named
@RequestScoped
public class DepartmentBean implements Serializable{
	private EntityManager entityManager = EntityManagerUtil.getEntityManager();
	private List<Department> departmentList;
	
	public DepartmentBean() {
	}

	public List<Department> getDepartmentList() {
		String hql = "FROM Department";
		List<Department> list = (List<Department>) entityManager.createQuery(hql).getResultList();
		return list;
	}

	public void setDepartmentList(List<Department> departmentList) {
		this.departmentList = departmentList;
	}

}
