package com.synergix.jpademo.beans;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import com.synergix.jpademo.helper.EntityManagerUtil;

@Named
@RequestScoped

public class EmployeeBean implements Serializable {
//	@PersistenceContext(unitName = "JPADemo", type = PersistenceContextType.TRANSACTION)
//	private EntityManager entityManager;
	private EntityManager entityManager = EntityManagerUtil.getEntityManager();
	private List<Employee> employeeList;
	
	
	public EmployeeBean() {
//		entityManager = emf.createEntityManager();
	}

	public Employee getEmployeeById(int id) {
		return entityManager.find(Employee.class, id);
	}
	
	public List<Employee> getEmployeeList() {
		String hql = "FROM Employee";
		List<Employee> list = (List<Employee>) entityManager.createQuery(hql).getResultList();
		return list;
	}
	
	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}

}
