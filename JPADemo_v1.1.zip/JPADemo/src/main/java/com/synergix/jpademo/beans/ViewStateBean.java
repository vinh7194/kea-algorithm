package com.synergix.jpademo.beans;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

@Named("bean")
@ConversationScoped
public class ViewStateBean implements Serializable {
	@Inject
    private Conversation conversation;
	
	@Inject
	private EmployeeBean employeeBean;
	@Inject
	private DepartmentBean departmentBean;
	
	private List<Employee> employeeList;
	private List<Department> departmentList;

	public List<Employee> getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}

	public List<Department> getDepartmentList() {
		return departmentList;
	}

	public void setDepartmentList(List<Department> departmentList) {
		this.departmentList = departmentList;
	}

	
	public void initConversation(){
		if (!FacesContext.getCurrentInstance().isPostback() 
			&& conversation.isTransient()) {
			
			conversation.begin();
			this.employeeList = employeeBean.getEmployeeList();
		}
	}
	
	public void endConversation(){
		if(!conversation.isTransient()){
			conversation.end();
		}
	}
	
	
	public void changeView(String view) {
		if(!conversation.isTransient()){
			conversation.end();
		}
		if(view.equals("employee")) {
			this.employeeList = employeeBean.getEmployeeList();
			this.departmentList = null;
		}else if (view.equals("department")) {
			this.employeeList = null;
			this.departmentList = departmentBean.getDepartmentList();
		}
		conversation.begin();
	}
}
