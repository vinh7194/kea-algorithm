package com.synergix.jpademo.test;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.synergix.jpademo.beans.Employee;
import com.synergix.jpademo.beans.EmployeeBean;

public class DAOTest {
	public static void main(String[] args) {
//		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPADemo");
//        EntityManager entityManager = factory.createEntityManager();
//         
//        entityManager.getTransaction().begin();
//         
////        User newUser = new User();
////        newUser.setEmail("billjoy@gmail.com");
////        newUser.setFullname("bill Joy");
////        newUser.setPassword("billi");
////         
////        entityManager.persist(newUser);
////         
////        entityManager.getTransaction().commit();
//        
//        Integer primaryKey = 1;
//        Employee employee = entityManager.find(Employee.class, primaryKey);
//         
//        System.out.println(employee.getName());
////        System.out.println(user.getFullname());
////        System.out.println(user.getPassword());
//         
//        entityManager.close();
//        factory.close();
		
		EmployeeBean employeeBean = new EmployeeBean();
		List<Employee> listEmpoyee = employeeBean.getEmployeeList();
		for(Employee employee: listEmpoyee) {
			System.out.println(employee.getName());
		}
	}
}
