package synergix.week1;

import java.util.Arrays;
import java.util.List;

public class GenericDemo {

	public static void main(String[] args) {
		GenericDemo genericDemo = new GenericDemo();

		// generic type demo
		Pair<String, Integer> p1 = new OrderedPair<String, Integer>("Even", 8);
		Pair<String, String> p2 = new OrderedPair<String, String>("hello", "world");

		Box<String> stringBox = new Box<>();
		Box rawBox = stringBox; // OK
		rawBox.set(8); // warning: unchecked invocation to set(T)

		rawBox = new Box();
		Box<Integer> intBox = rawBox; // warning: unchecked conversion

		// generic method demo
		OrderedPair<Integer, String> p3 = new OrderedPair<>(1, "apple");
		OrderedPair<Integer, String> p4 = new OrderedPair<>(2, "pear");
		boolean same = Util.compare(p3, p4);

		//bounder generic
		Box<Integer> integerBox = new Box<Integer>();
		integerBox.set(new Integer(10));
//		 integerBox.inspect("some text"); // error: this is still String!
		
		//upper wildcard
		List<Integer> li = Arrays.asList(1, 2, 3);
		System.out.println("sum = " + Util.sumOfList(li));
		
		//unbounder wildcard
		li = Arrays.asList(1, 2, 3);
		List<String>  ls = Arrays.asList("one", "two", "three");
		Util.printList(li);
		Util.printList(ls);
		
//		Box<String>[] boxes= new Box[];

	}

}

interface Pair<K, V> {
	public K getKey();

	public V getValue();
}

class OrderedPair<K, V> implements Pair<K, V> {

	private K key;
	private V value;

	public OrderedPair(K key, V value) {
		this.key = key;
		this.value = value;
	}

	public K getKey() {
		return key;
	}

	public V getValue() {
		return value;
	}
}

class Box<T> {
	// T stands for "Type"
	private T t;

	public void set(T t) {
		this.t = t;
	}

	public T get() {
		return t;
	}

	public <U extends Number> void inspect(U u) {
		System.out.println("T: " + t.getClass().getName());
		System.out.println("U: " + u.getClass().getName());
	}
}

class Util {
	public static <K, V> boolean compare(Pair<K, V> p1, Pair<K, V> p2) {
		return p1.getKey().equals(p2.getKey()) && p1.getValue().equals(p2.getValue());
	}
	
	public static <T extends Comparable<T>> int countGreaterThan(T[] anArray, T elem) {
	    int count = 0;
	    for (T e : anArray)
	        if (e.compareTo(elem) > 0)  // compiler error
	            ++count;
	    return count;
	}
	
	public static double sumOfList(List<? extends Number> list) {
	    double s = 0.0;
	    for (Number n : list)
	        s += n.doubleValue();// can using method in number
	    return s;
	}
	
	//unbounder wildcard
	public static void printList(List<?> list) {
	    for (Object elem: list)
	        System.out.print(elem + " ");
	    System.out.println();
	}
	
	//lower bounder wildcard
	public static void addNumbers(List<? super Integer> list) {
	    for (int i = 1; i <= 10; i++) {
	        list.add(i);
	    }
	}
	
}

class NaturalNumber<T extends Integer> {

    private T n;

    public NaturalNumber(T n)  { this.n = n; }

    public boolean isEven() {
        return n.intValue() % 2 == 0;
    }
}