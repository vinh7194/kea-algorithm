package synergix.week1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TryWithResourceStatement {
	static String readFirstLineFromFile(String fileName) throws IOException {
		try (
			BufferedReader br = new BufferedReader(new FileReader(fileName))
		){
			return br.readLine();
		}
	}

	public static void main(String[] args) throws Exception{
		readFirstLineFromFile("test.txt");
	}
}
