package synergix.week1;

import java.text.DecimalFormat;

public class NumberDemo {
	static public void customFormat(String pattern, double value) {
		DecimalFormat myFormatter = new DecimalFormat(pattern);
		String output = myFormatter.format(value);
		System.out.println(value + "  " + pattern + "  " + output);
	}

	public static void main(String[] args) {
		int n = 46112;
		System.out.format("%06d%n", n); // --> "00461012"
		System.out.format("%+,6d%n", n);

		double pi = Math.PI;
		System.out.format("%8.3f%n", pi); // --> "     3.142"
		
		System.out.println("-------------------------------");
		customFormat("###,###.###", 6123456.789);
		customFormat("###.##", 123456.789);
		customFormat("000000.000", 123.78);
		customFormat("$###,###.###", 12345.67);
	}
}
