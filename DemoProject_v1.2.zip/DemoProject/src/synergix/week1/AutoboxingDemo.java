package synergix.week1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AutoboxingDemo {
	public static void main(String[] args) {
		//autoboxing through asignment
		Character ch = 'a';
		
		//autoboxing through generic
		List<Integer> li = new ArrayList<>();
		for (int i = 1; i < 50; i += 2)
		    li.add(i);
		
		System.out.println(Arrays.toString(li.toArray()));
	}
}
