package synergix.week1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateDemo {
	public static void main(String[] args) {
		// Instantiate a Date object
		Date currentDate = new Date();
		// display time and date using toString()
		System.out.println(currentDate.toString());
		System.out.println();

		// date format
		SimpleDateFormat ft = new SimpleDateFormat("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
		System.out.println("Current Date: " + ft.format(currentDate));
		// display time and date
		String str = String.format("Current Date/Time : %tc", currentDate);
		System.out.printf(str);
		System.out.println("\n");

		// parse string to date
		ft = new SimpleDateFormat("yyyy-MM-dd");
		String input = "1818-11-26";
		System.out.print(input + " Parses as ");
		Date t;
		try {
			t = ft.parse(input);
			System.out.println(t);
			ft = new SimpleDateFormat("dd/MM/yyyy");
			System.out.println(ft.format(t));
		} catch (ParseException e) {
			System.out.println("Unparseable using " + ft);
		}
		System.out.println();

		// Measuring Elapsed Time
		try {
			long start = System.currentTimeMillis();
			System.out.println(new Date() + "\n");

			Thread.sleep(300);
			System.out.println(new Date() + "\n");

			long end = System.currentTimeMillis();
			long diff = end - start;
			System.out.println("Difference is : " + diff);
		} catch (Exception e) {
			System.out.println("Got an exception!");
		}
		System.out.println();

		
		//GregorianCalendarDemo
		String months[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
		int year;
		// Create a Gregorian calendar initialized with the current date and time in the default locale and timezone.
		GregorianCalendar gcalendar = new GregorianCalendar();
		// Display current time and date information.
		System.out.print("Date: ");
		System.out.print(months[gcalendar.get(Calendar.MONTH)]);
		System.out.print(" " + gcalendar.get(Calendar.DATE) + " ");
		System.out.println(year = gcalendar.get(Calendar.YEAR));
		System.out.print("Time: ");
		System.out.print(gcalendar.get(Calendar.HOUR) + ":");
		System.out.print(gcalendar.get(Calendar.MINUTE) + ":");
		System.out.println(gcalendar.get(Calendar.SECOND));

		// Test if the current year is a leap year
		if (gcalendar.isLeapYear(year)) {
			System.out.println("The current year is a leap year");
		} else {
			System.out.println("The current year is not a leap year");
		}
	}
}
