package synergix.demoweekly;

public class Hello {
	public static void main(String[] args) {
		System.out.println("Hello");
		StringBuilder stringBuilder = new StringBuilder("Hello");
		stringBuilder.append("VietNam");
//		stringBuilder.reverse();
//		stringBuilder.insert(3, "abc");
		System.out.println(stringBuilder);
		
		int n = 46112;
		System.out.format("%06d%n", n);    //  -->  "00461012"
		System.out.format("%+,6d%n", n);
		
		double pi = Math.PI;
		System.out.format("%8.3f%n", pi);   // -->  "     3.142"
		
		String quote = 
			    "Now is the time for all good " +
			    "men to come to the aid of their country.";
	}
}
